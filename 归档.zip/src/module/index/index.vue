<template>
  <div class="index">
    <ul>
      <li
        v-for="item in list">
        <p>{{item.email}}</p>  
        <p>{{item.color}}</p>  
      </li>
    </ul>
    <p>{{getFavoriteListLength}}</p>
    <button @click="ADD_FAVORITE">addFavorite</button>
  </div>
</template>

<script type="text/babel">
// import { mapActions , mapState, mapGetters, mapMutations } from 'vuex'
// import datePicker from 'vue-ios-datepicker'
import { mapState, mapActions, mapGetters } from 'vuex'
export default {
  data () {
    return {
      localList: [
        {email: 'aaa.aaa.aa', color: 'blue'}
      ]
    }  
  },
  computed: {
    ...mapState({
      // list: state => state.favoriteList,
      // list: 'favoriteList', // 等于 state => state.favoriteList,
      list (state) {
        return state.favoriteList.concat(this.localList)
      }
    }),
    ...mapGetters([
      'getFavoriteListLength'
    ]),
    // list () {
    //   return this.$store.state.favoriteList
    // }
  },
  mounted () {
  },
  methods: {
    ...mapActions([
      'ADD_FAVORITE' // 映射 this.ADD_FAVORITE() 到 this.$store.dispatch('ADD_FAVORITE')
    ]),
    // ...mapActions({
    //   addFavorite: 'ADD_FAVORITE' // 映射 this.addFavorite() to this.$store.dispatch('ADD_FAVORITE')
    // })
  }
}
</script>

<style lang="stylus" scoped>
</style>