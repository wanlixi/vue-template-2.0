// BACK-END DATA REQUEST CENTER

import fetch from './config'

export default {
    addFavorite () {
    	return fetch(`https://github.com/wanlixi/${process.env.NODE_ENV}/addFavorite`, 'post');
    }
}
