// export const GET_USER_INFO = ({dispatch}) => dispatch('GET_USER_INFO');
// export const GET_USER_FAVORITE = ({dispatch}) => dispatch('GET_USER_FAVORITE');
// export const ADD_FAVORITE = ({dispatch}, newFavorite) => dispatch('ADD_FAVORITE', newFavorite);

import * as types from './types'
import api from '../api'

export default {
	async ADD_FAVORITE ({commit}) {
		await api.addFavorite()
			.then( res => {
				commit(types.ADD_FAVORITE, res)
			})
			.catch( err => {

			})
	}
	// ADD_FAVORITE ({commit}) {
	// 	console.log('commit')
	// 	commit(types.ADD_FAVORITE, {email: 123})
	// }
}