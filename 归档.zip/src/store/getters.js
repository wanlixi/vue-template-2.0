// 有的组件中获取到 store 中的state,  需要对进行加工才能使用，computed 属性中就需要写操作函数，如果有多个组件中都需要进行这个操作，那么在各个组件中都写相同的函数，那就非常麻烦，这时可以把这个相同的操作写到store 中的getters,  每个组件只要引用getter 就可以了，非常方便。Getter 就是把组件中共有的对state 的操作进行了提取，它就相当于 对state 的computed. 所以它会获得state 作为第一个参数。
// 个人总结就是为了解决一个地方改了中央数据的某一个字段，其他地方都需要computed进行对中央数据的计算

export default {
	getFavoriteListLength (state) {
		return state.favoriteList.length;
	}
}