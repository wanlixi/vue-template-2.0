
import * as types from './types';
import store from './index';
import api from '../api';

const mutations = {
  [types.ADD_FAVORITE] (state, res) {
    // state.favoriteList = state.favoriteList.concat(res.list)
    state.favoriteList = [...state.favoriteList, res.list];
  }
};
export default mutations;