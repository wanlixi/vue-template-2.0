// 初始化样式和全局样式
import './iview-style/index.less'
import './css/common/normalize.css'
import './css/common/var.styl'
import './css/common/function.styl'
// import 'assets/font/iconfont.css'
// import 'assets/css/css.css'
// import 'assets/css/main.css'
import C from './js/conf'
import M from './js/common'

// 修改第三方UI库样式
// import 'assets/css/iview/message.styl'
// import 'assets/css/iview/select.styl'
// import 'assets/css/iview/select2.styl'
// import 'assets/css/iview/cascader.styl'
import './css/iview/modal.styl'
// import 'assets/css/iview/table.styl'
// import 'assets/css/iview/input.styl'
// import 'assets/css/iview/icon.styl'

// module.exports = { M , C };
export {M , C}