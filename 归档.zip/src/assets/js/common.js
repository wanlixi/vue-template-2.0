// 全局类
var Rxports = {
	
};
module.exports = Rxports