module.exports = {
  NODE_ENV: '"test"'
}