# template

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# 如果用到单元测试需要在babelrc文件里面加
"env": {
  "test": {
    "presets": ["env", "stage-2"],
    "plugins": [ "istanbul" ]
  }
}

